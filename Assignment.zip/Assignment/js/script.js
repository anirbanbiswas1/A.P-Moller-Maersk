var totalDigit = []; 
var shuffle_box = ''; 
function getShuffleValue(min, max) { 
	console.log(min, max); 
	min = Math.ceil(min); 
	max = Math.floor(max); 
	if (totalDigit.length <= 8) { 
		let  num = Math.floor(Math.random() * (max - min + 1)) + min; 
		if (!totalDigit.includes(num)) { 
			totalDigit.push(num); var colorBackg = ''; 
			if (totalDigit.indexOf(num) === 0 || totalDigit.indexOf(num) === 7) { 
				colorBackg = 'box-color1';
			} else if (totalDigit.indexOf(num) === 1 || totalDigit.indexOf(num) === 3) { 
				colorBackg = 'box-color2';
			} else if (totalDigit.indexOf(num) === 2 || totalDigit.indexOf(num) === 4 || totalDigit.indexOf(num) === 8 ) { 
				colorBackg = 'box-color3';
			} else if (totalDigit.indexOf(num) === 5 || totalDigit.indexOf(num) === 6) { 
				colorBackg = 'box-color4';
			} 
			shuffle_box += '<div class="tile '+colorBackg+'" data-index="'+totalDigit.indexOf(num)+'">'+num+'</div>'; 
		} 
		getShuffleValue(1, 9); 
	} 
}

function getSortValue() { 
	console.log("totalDigit.length", totalDigit.length); 
	if (totalDigit.length === 9) { 
		totalDigit = totalDigit.sort(); 
		for (let num = 1; num <= totalDigit.length; num++) { 
			var colorBackg = ''; 
			if (totalDigit.indexOf(num) === 0 || totalDigit.indexOf(num) === 7) { 
				colorBackg = 'box-color1';
			} else if (totalDigit.indexOf(num) === 1 || totalDigit.indexOf(num) === 3) { 
				colorBackg = 'box-color2';
			} else if (totalDigit.indexOf(num) === 2 || totalDigit.indexOf(num) === 4 || totalDigit.indexOf(num) === 8 ) { 
				colorBackg = 'box-color3';
			} else if (totalDigit.indexOf(num) === 5 || totalDigit.indexOf(num) === 6) { 
				colorBackg = 'box-color4';
			} 
			shuffle_box += '<div class="tile '+colorBackg+'" data-index="'+totalDigit.indexOf(num)+'">'+(num)+'</div>'; 
		} 
	} 
}
var shuffle_button = document.getElementById('shuffle_button'); 
setTimeout(function () { 
	shuffle_button.click(); 
}, 100)
shuffle_button.addEventListener('click', event => { 
	console.log('click'); 
	totalDigit = []; 
	shuffle_box = '';   
	getShuffleValue(1, 9); 
	console.log(shuffle_box);
	document.getElementById('tile-board').innerHTML = shuffle_box; 
});
var sort_button = document.getElementById('sort_button'); 
sort_button.addEventListener('click', event => { 
	console.log('click sort'); 
	shuffle_box = ''; getSortValue(); 
	document.getElementById('tile-board').innerHTML = shuffle_box; 
});